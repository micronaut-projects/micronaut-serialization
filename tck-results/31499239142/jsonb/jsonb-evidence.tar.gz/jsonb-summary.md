# Jakarta JSON-B TCK Evidence

- Commit: 405eeaa54f41f56b6acdc1595cfb4eabf39b468d
- Project version: 3.1.1-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.2
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.2
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/31499239142
- Sanitized JUnit XML: junit-xml/
- Tests: 295
- Failures: 0
- Errors: 0
- Skipped: 5
