# Jakarta JSON-P TCK Evidence

- Commit: e61973b3c2a502b7245624cea3e739ce11a6a3a1
- Project version: 3.3.0-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.3
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.3
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/38134035299
- Sanitized JUnit XML: junit-xml/
- Tests: 179
- Failures: 0
- Errors: 0
- Skipped: 0
