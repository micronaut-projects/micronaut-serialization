# Jakarta JSON-B TCK Evidence

- Commit: 6a18f3cbf475ed57e935dfa2f995fd9ec39e3c6a
- Project version: 3.0.1-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.2
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.2
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/28504982780
- Sanitized JUnit XML: junit-xml/
- Tests: 295
- Failures: 0
- Errors: 0
- Skipped: 5
