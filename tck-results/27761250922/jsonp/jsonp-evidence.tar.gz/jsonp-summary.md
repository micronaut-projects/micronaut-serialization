# Jakarta JSON-P TCK Evidence

- Commit: 55759a87dcecefe685c3bc8937e478abb641105c
- Project version: 3.0.1-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.2
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.0
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/27761250922
- Sanitized JUnit XML: junit-xml/
- Tests: 179
- Failures: 0
- Errors: 0
- Skipped: 0
