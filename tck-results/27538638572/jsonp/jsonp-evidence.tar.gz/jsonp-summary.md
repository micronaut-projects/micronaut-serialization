# Jakarta JSON-P TCK Evidence

- Commit: 4bc98c62bc64526bc615588b05d191693664035e
- Project version: 3.0.1-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.2
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.0
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/27538638572
- Sanitized JUnit XML: junit-xml/
- Tests: 179
- Failures: 0
- Errors: 0
- Skipped: 0
