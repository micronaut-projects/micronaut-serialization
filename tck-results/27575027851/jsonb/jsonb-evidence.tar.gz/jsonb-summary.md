# Jakarta JSON-B TCK Evidence

- Commit: adcafd820909453b207d47b8f4cde621d68f5b95
- Project version: 3.0.1-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.2
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.0
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/27575027851
- Sanitized JUnit XML: junit-xml/
- Tests: 295
- Failures: 0
- Errors: 0
- Skipped: 5
