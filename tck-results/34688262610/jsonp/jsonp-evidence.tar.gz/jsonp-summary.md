# Jakarta JSON-P TCK Evidence

- Commit: 7f331937233f2d6de71a4c14688512fb820d312d
- Project version: 3.2.0-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.3
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.3
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/34688262610
- Sanitized JUnit XML: junit-xml/
- Tests: 179
- Failures: 0
- Errors: 0
- Skipped: 0
