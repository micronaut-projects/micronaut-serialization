# Jakarta JSON-B TCK Evidence

- Commit: ecdd4e030c72c248aedf4c02bc94e1ca9d23cd96
- Project version: 3.0.1-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.2
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.0
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/27761538945
- Sanitized JUnit XML: junit-xml/
- Tests: 295
- Failures: 0
- Errors: 0
- Skipped: 5
