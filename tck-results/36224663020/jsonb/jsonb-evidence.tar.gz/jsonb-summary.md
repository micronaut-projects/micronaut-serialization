# Jakarta JSON-B TCK Evidence

- Commit: 8dfb0aa77f200748f5528a36462e647f0235bbab
- Project version: 3.2.3-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.3
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.3
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/36224663020
- Sanitized JUnit XML: junit-xml/
- Tests: 295
- Failures: 0
- Errors: 0
- Skipped: 6
