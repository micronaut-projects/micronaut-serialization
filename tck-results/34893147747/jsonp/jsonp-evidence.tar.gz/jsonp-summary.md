# Jakarta JSON-P TCK Evidence

- Commit: 8be06d0b9db05135c4aad5cd25c4e90d8ec34ef3
- Project version: 3.2.0-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.3
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.3
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/34893147747
- Sanitized JUnit XML: junit-xml/
- Tests: 179
- Failures: 0
- Errors: 0
- Skipped: 0
