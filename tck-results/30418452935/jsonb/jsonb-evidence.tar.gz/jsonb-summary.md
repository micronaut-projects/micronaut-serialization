# Jakarta JSON-B TCK Evidence

- Commit: e53223ebfef9498064afef0da5a75eeb07515207
- Project version: 3.1.1-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.2
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.2
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/30418452935
- Sanitized JUnit XML: junit-xml/
- Tests: 295
- Failures: 0
- Errors: 0
- Skipped: 5
