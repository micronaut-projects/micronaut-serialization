# Jakarta JSON-P TCK Evidence

- Commit: b29623a5d22babb2ab8c5112fcf6362e84ffbf8c
- Project version: 3.1.1-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.2
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.2
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/31481264118
- Sanitized JUnit XML: junit-xml/
- Tests: 179
- Failures: 0
- Errors: 0
- Skipped: 0
