# Jakarta JSON-B TCK Evidence

- Commit: 7526eebec140f5b171c53edbca0f336e58732524
- Project version: 3.3.0-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.4
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.4
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/45829226339
- Sanitized JUnit XML: junit-xml/
- Tests: 295
- Failures: 0
- Errors: 0
- Skipped: 6
