# Jakarta JSON-P TCK Evidence

- Commit: 44e39ef5badeb84e5aa7c0d30c3cf896368c0fdc
- Project version: 3.3.0-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.4
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.4
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/41302656902
- Sanitized JUnit XML: junit-xml/
- Tests: 179
- Failures: 0
- Errors: 0
- Skipped: 0
