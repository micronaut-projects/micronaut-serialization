# Jakarta JSON-P TCK Evidence

- Commit: 30668098818dc7195445df6bc2e99bb5e497e36e
- Project version: 3.2.5-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.3
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.3
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/39220767583
- Sanitized JUnit XML: junit-xml/
- Tests: 179
- Failures: 0
- Errors: 0
- Skipped: 0
