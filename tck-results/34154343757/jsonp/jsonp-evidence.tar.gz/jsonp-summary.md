# Jakarta JSON-P TCK Evidence

- Commit: c1ca4dccdc92f66f6b2a8089c54dd0d7b4a7dfcd
- Project version: 3.1.2-SNAPSHOT
- JSON-P API baseline: 2.1.3
- JSON-B API baseline: 3.0.2
- JSON-P TCK: 2.1.1
- JSON-B TCK: 3.0.2
- Workflow: https://github.com/micronaut-projects/micronaut-serialization/actions/runs/34154343757
- Sanitized JUnit XML: junit-xml/
- Tests: 179
- Failures: 0
- Errors: 0
- Skipped: 0
